document.addEventListener('DOMContentLoaded', () => {
  // Select all category buttons
  const categoryButtons = document.querySelectorAll('.category-btn');
  
  // Select all category contents
  const categoryContents = document.querySelectorAll('.category-content');
  
  // Function to hide all category contents
  function hideAllCategories() {
    categoryContents.forEach(content => {
      content.style.display = 'none';
    });
  }

  // Add event listeners to all category buttons
  categoryButtons.forEach(button => {
    button.addEventListener('click', () => {
      // Get the category that was clicked
      const category = button.getAttribute('data-category');
      
      // Hide all category contents
      hideAllCategories();
      
      // Show the selected category content
      const selectedCategory = document.getElementById(`${category}Content`);
      if (selectedCategory) {
        selectedCategory.style.display = 'block';
      }
    });
  });

  // Optionally, show the first category by default (e.g., "clothes")
  document.querySelector('.category-btn[data-category="clothes"]').click();
});
